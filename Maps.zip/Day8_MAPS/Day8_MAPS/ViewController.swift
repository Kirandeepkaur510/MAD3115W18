//
//  ViewController.swift
//  Day8_MAPS
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 Kirandeep. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {

    @IBOutlet weak var myMap: MKMapView!
    
    let lambtonCollegeLocation = CLLocation(latitude:43.773357, longitude: -79.335899)
    let regionRadius: CLLocationDistance = 100
    let locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        myMap.mapType = MKMapType.standard
        centerMapOnLocation(location: lambtonCollegeLocation, title: "Lambton College", subTitle: "265 Yorkland Blvd")
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  //center map on specified location
    func centerMapOnLocation(location: CLLocation, title: String, subTitle: String){
        //get the location coordinates
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,regionRadius,regionRadius)
        
        //focus the map on specified location
        myMap.setRegion(coordinateRegion, animated: true)
        
        //drop a pin at user's current location
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = title
        myAnnotation.subtitle = subTitle
        //display on pin
        myMap.addAnnotation(myAnnotation)
        
    }


}

