//
//  ParkingReciptReport.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class ParkingReciptReport: UIViewController {

    @IBOutlet weak var RegNumber: UILabel!
    
    @IBOutlet weak var Date: UILabel!
    
    @IBOutlet weak var Hours: UILabel!
    
    @IBOutlet weak var Amount: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        RegNumber.text = GlobalVariables.paid_VehicleRegNumber[GlobalVariables.paid_ticketIndex]
        Date.text = String(describing: GlobalVariables.paid_ParkingDate[GlobalVariables.paid_ticketIndex])
        Hours.text = String(GlobalVariables.paid_ParkingHours[GlobalVariables.paid_ticketIndex])
        Amount.text = "$ \(GlobalVariables.paid_Amt[GlobalVariables.paid_ticketIndex])"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
