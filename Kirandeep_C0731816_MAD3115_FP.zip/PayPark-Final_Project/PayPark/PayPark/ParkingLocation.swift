//
//  ParkingLocation.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-23.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit
import MapKit

class ParkingLocation: UIViewController {

    @IBOutlet weak var MapView: MKMapView!
    
    @IBAction func Location(_ sender: UIButton) {
        
        let mitCoordinates = CLLocation(latitude: 43.659434, longitude: -79.756659)
        LoadCurrentLocation(location: mitCoordinates, title: "Home", subtitle: "HomeNew!!")

    }
    

    
    
    
    
    @IBAction func currentLoc(_ sender: UIButton) {
        let currenCoordinates = CLLocation(latitude: current_lat!, longitude: current_long!)
        LoadCurrentLocation(location: currenCoordinates, title: "Your Current Location!", subtitle: "You are here.")
    }
    

    
    
    
    var myLoc_langitude = 43.773174
    var myLoc_longitude = -79.335824
    var myLoc_Title = "Lambton College, Toronto"
    var myLoc_SubTitle = "Lambton College has licensed its curriculum to Cestar College to deliver its academic programs to international students in Toronto."
    
    var current_lat: Double?
    var current_long: Double?
    
    let locationManager =  CLLocationManager()
    let regionRadius: CLLocationDistance = 100
   var resultSearchController : UISearchController? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        //embeb search bar to viewcontroller
        
        let locationSearchTable = storyboard!.instantiateViewController(withIdentifier: "SearchResultScreen") as! MapControls
        
        resultSearchController = UISearchController(searchResultsController: locationSearchTable)
        
        resultSearchController?.searchResultsUpdater = locationSearchTable
        
        //appearance of search bar
        
        let searchBar = resultSearchController!.searchBar
        
        searchBar.sizeToFit()
        
        searchBar.placeholder = "Search for places"
        
        navigationItem.titleView = resultSearchController?.searchBar
        
        resultSearchController?.hidesNavigationBarDuringPresentation = false
        
        resultSearchController?.dimsBackgroundDuringPresentation = false
        
        definesPresentationContext = true
        
        
        
        //set map appearance
        
        MapView.mapType = MKMapType.standard
        
        MapView.isZoomEnabled = true
        
        MapView.isScrollEnabled = true
        // Do any additional setup after loading the view.
        //LoadMyLocation(Lat: myLoc_langitude, Long: myLoc_longitude, LocTitle: myLoc_Title, LocSubTitle: myLoc_SubTitle)
        
        
        // Do any additional setup after loading the view.
        //LoadMyLocation(Lat: myLoc_langitude, Long: myLoc_longitude, LocTitle: myLoc_Title, LocSubTitle: myLoc_SubTitle)
        findAndLoadCurrentLocation()
        locationSearchTable.mapView = MapView
        
    }

    func findAndLoadCurrentLocation() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.startUpdatingLocation()
        }
    }
    
    
    func LoadCurrentLocation(location: CLLocation,title: String , subtitle:String){
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)
        //focus on specified location
        MapView.setRegion(coordinateRegion, animated: true)
        //drop a pin
        let myAnnotation:MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = title
        myAnnotation.subtitle = subtitle
        //display pin on location
        MapView.addAnnotation(myAnnotation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Parking Location"

        /*------Add Side Button ------*/
        
    }

}

extension ParkingLocation: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error::\(error.localizedDescription)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.requestLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if locations.first != nil {
            print("Locations : \(locations)")
        }
        
       current_lat = locationManager.location?.coordinate.latitude
        current_long = locationManager.location?.coordinate.longitude
        
       LoadCurrentLocation(location: locationManager.location!, title: "Current Location", subtitle: "You are here!")
       //LoadMyLocation(Lat: locationManager.location!.coordinate.latitude, Long: locationManager.location!.coordinate.longitude, LocTitle: "Current Location", LocSubTitle: "You are here!")
        
        
        print("Updating location")
        
        
        
        let center = CLLocationCoordinate2D(latitude: (locationManager.location?.coordinate.latitude)!, longitude: (locationManager.location?.coordinate.longitude)!)
        
        print("Center : \(center)")
        
        
        
        let region = MKCoordinateRegionMakeWithDistance(center,regionRadius, regionRadius)
        
        self.MapView.setRegion(region, animated: true)
        
        
        
        // Drop a pin at user's Current Location
        
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        
        myAnnotation.coordinate = center
        
        myAnnotation.title = "Current location"
        
        MapView.addAnnotation(myAnnotation)
        
        
    }
        
    }


