//
//  registerVC.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class registerVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
  
    var userItems: UserItems!

    
    @IBOutlet weak var Fname: UITextField!
    
    @IBOutlet weak var Lname: UITextField!
    
    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var Phone: UITextField!
    
    @IBOutlet weak var Pswrd1: UITextField!
    
    @IBOutlet weak var Pswrd2: UITextField!
    
    @IBOutlet weak var DOB_User: UIDatePicker!
    
    @IBOutlet weak var CityTxt: UITextField!
    
    @IBAction func Register(_ sender: UIButton) {
        
        displayValues()
        
    }
    
    var cityList: [String] = ["Barrie","Belleville","Brampton","Brant","Brantford","Brockville","Burlington","Cambridge","Clarence-Rockland","Cornwall","Dryden","Elliot Lake","Greater Sudbury","Guelph","Haldimand County","Hamilton","Kawartha Lakes","Kenora","Kingston","Kitchener","London","Markham","Mississauga","Niagara Falls","Norfolk County","North Bay","Orillia","Oshawa","Ottawa","Owen Sound","Pembroke","Peterborough","Pickering","Port Colborne","Prince Edward County","Quinte West","Sarnia","Sault Ste. Marie","St. Catharines","St. Thomas","Stratford","Temiskaming Shores","Thorold","Thunder Bay","Timmins","Toronto","Vaughan","Waterloo","Welland","Windsor","Woodstock"]
    
    
    
    
    var selectedCityIndex : Int = 0
    var selectedDateIndex : Int = 0
 
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Registration"
        
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayValues))
        
        self.navigationItem.rightBarButtonItem = btnSubmit
    }
    
    
    @objc private func displayValues() {
        let firstn = Fname.text
        let lastn = Lname.text
        let eml = Email.text
        let phn = Phone.text
        let pwrd1 = Pswrd1.text
        let pwrd2 = Pswrd2.text
        
        if firstn == "" || lastn == "" || eml == "" || phn == "" || pwrd1 == "" || pwrd2 == ""
        {
            let infoAlert = UIAlertController(title: "Information Missing!", message: "Please enter all the details before submission!", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true)
            
        }
        else if pwrd1 != pwrd2 {
            let infoAlert = UIAlertController(title: "Password Error!", message: "Password Doesn't Match!", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true)
            
        }
        else {
            
            let alldata : String = """
            First Name: \(firstn!)
            Last Name: \(lastn!)
            Date: \(self.DOB_User.date)
            E-Mail: \(eml!)
            Phone: \(phn!)
            City: \(CityTxt.text!)
            """
            
            let infoAlert = UIAlertController(title: "Verify", message: alldata, preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.userRegistration()}))
             infoAlert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            self.present(infoAlert, animated: true)
            
        }
        
    }
    
    func userRegistration () {
        
        let email_new = Email.text

        for i in 0..<GlobalVariables.g_usrName.count {
            if GlobalVariables.g_usrName[i] == email_new {
                 let infoAlert = UIAlertController(title: "Registration Error!", message: "EMail/Username already exist!", preferredStyle: .alert)
            
                infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(infoAlert, animated: true)
             }
           else
            {
                continue
            }
        }
        
        GlobalVariables.g_firName.append(Fname.text!)
        GlobalVariables.g_lasName.append(Lname.text!)
        GlobalVariables.g_dtofBirth.append(self.DOB_User.date)
        GlobalVariables.g_city.append(self.cityList[selectedCityIndex])
        GlobalVariables.g_usrName.append(Email.text!)
        GlobalVariables.g_phn.append(Int(Phone.text!)!)
        GlobalVariables.g_pssWrd.append(Pswrd1.text!)
        userItems.currentUser = Email.text
        GlobalVariables.LoggedUser = Email.text!
        
        
        /*
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "Welcome") as! WelcomeVC
        
        welcomeVC.welcomeTitle = Fname.text!
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
        */
        
        let infoAlert = UIAlertController(title: "Registration Successful!", message: "Please Login with entered details!", preferredStyle: .alert)
        infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in self.displayLoginScreen()}))
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    func displayLoginScreen () {
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "LoginPage")
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
          userItems = UserItems()
        
        pickerView.delegate = self
        pickerView.dataSource = self
        CityTxt.inputView = pickerView
        CityTxt.textAlignment = .left

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
    var pickerView = UIPickerView()
    
    func numberOfComponents(in pickerView:UIPickerView) -> Int{
        return 1
    }
    func pickerView(_ pickerView: UIPickerView ,numberOfRowsInComponent component: Int) -> Int {
        return self.cityList.count
    }
    
    func pickerView(_ pickerView: UIPickerView ,titleForRow row : Int , forComponent component : Int) -> String?{
        return self.cityList[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        CityTxt.text = cityList[row]
        CityTxt.resignFirstResponder()
    }
   
    
    class ColoredDatePicker: UIDatePicker {
        var changed = false
        override func addSubview(_ view: UIView) {
            if !changed {
                changed = true
                self.setValue(UIColor.white, forKey: "textColor")
            }
            super.addSubview(view)
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
