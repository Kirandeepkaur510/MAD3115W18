//
//  WelcomeVC.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class WelcomeVC: UIViewController {

    var Hrs: Int = 0
    var minutes: Int = 0
    var seconds: Int = 0
    var timer = Timer()
    
    var welcomeTitle: String = "Test"
    
    @IBOutlet weak var Lbl_Second: UILabel!
    
    @IBOutlet weak var Lbl_Minutes: UILabel!
    
    @IBOutlet weak var Lbl_Hrs: UILabel!
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = self.welcomeTitle
        
        let btnlogout = UIBarButtonItem(title: "LogOut", style: .plain, target: self, action: #selector(displayValues))
        
        self.navigationItem.rightBarButtonItem = btnlogout
    }
    
    @objc private func displayValues() {
        
        GlobalVariables.RunTImerHrs = Hrs
        GlobalVariables.RunTimerMins = minutes
        GlobalVariables.RunTimerSecs = seconds
        
            let infoAlert = UIAlertController(title: "LogOut!", message: "Do you want to continue?", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayLoginScreen()}))
            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true)
            
        
    }
    
    func displayLoginScreen () {
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "LoginPage")
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        if GlobalVariables.RunTimer && GlobalVariables.RunTimeUser == GlobalVariables.LoggedUser
        {

            if GlobalVariables.RunTimerMins != 0 || GlobalVariables.RunTimerSecs != 0
            {
                seconds = GlobalVariables.RunTimerSecs
                minutes = GlobalVariables.RunTimerMins
                Hrs = GlobalVariables.RunTImerHrs
                
                Lbl_Hrs.text = String(Hrs)
                Lbl_Minutes.text = String(minutes)
                Lbl_Second.text = String(seconds)

            }
            else if GlobalVariables.RunTImerHrs == 1 {
                Hrs = 0
                minutes = 59
                seconds = 60
                Lbl_Hrs.text = String(Hrs)
                Lbl_Minutes.text = String(minutes)
                Lbl_Second.text = String(seconds)
            }
            else
            {
                Hrs = GlobalVariables.RunTImerHrs - 1
                minutes = 59
                seconds = 60
                Lbl_Hrs.text = String(Hrs)
                Lbl_Minutes.text = String(minutes)
                Lbl_Second.text = String(seconds)
            }
            
            
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(run_timer), userInfo: nil, repeats: true)
            
        }
        
        
        // Do any additional setup after loading the view.
    }

    
    @objc func run_timer ()
    {
        seconds = seconds - 1
        GlobalVariables.RunTimerSecs = seconds
        Lbl_Second.text = String(seconds)
        if seconds == 0
        {
            if minutes != 0
            {
            minutes = minutes - 1
            GlobalVariables.RunTimerMins = minutes
            Lbl_Minutes.text = String(minutes)
            seconds = 60
            GlobalVariables.RunTimerSecs = seconds
            Lbl_Second.text = String(seconds)
            }
            else
            {
                if Hrs != 0 {
                    Hrs = Hrs - 1
                    GlobalVariables.RunTImerHrs = Hrs
                    Lbl_Hrs.text = String(Hrs)
                    minutes = 60
                    GlobalVariables.RunTimerMins = minutes
                    Lbl_Minutes.text = String(minutes)
                    seconds = 60
                    GlobalVariables.RunTimerSecs = seconds
                    Lbl_Second.text = String(seconds)
                }
                else
                {
                    GlobalVariables.RunTImerHrs = Hrs
                    GlobalVariables.RunTimerMins = minutes
                    GlobalVariables.RunTimerSecs = seconds
                    timer.invalidate()
                }
            }
        }
        
    
 
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    


}
