//
//  ViewController.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class loginVC: UIViewController {

    var userItems: UserItems!
    
    
    @IBOutlet weak var UserNameText: UITextField!
   
    @IBOutlet weak var PasswordText: UITextField!
    
    @IBOutlet weak var RemeberSwitch: UISwitch!
    
    @IBAction func RemeberSwitchAction(_ sender: UISwitch) {
        if self.RemeberSwitch.isOn{
            GlobalVariables.LoginRemeber = true
            GlobalVariables.LoginUserName = UserNameText.text!
            GlobalVariables.LoginPassword = PasswordText.text!
            let saveAlert = UIAlertController(title: "Saved!", message: "Your data will be saved!", preferredStyle: .alert)
            
            saveAlert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Data saved!"), style: .default, handler: nil))
            
            
            self.present(saveAlert, animated: true, completion: nil)
            
        }
        
    }
    
    
    @IBAction func NewLogin(_ sender: UIButton) {
        let user = UserNameText.text
        let pass = PasswordText.text
        if user=="" && pass==""
        {
            let infoAlert = UIAlertController(title: "Login Detail Missing!", message: "Please Enter Username and Password.", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true, completion: nil)
            
        }
        else {
             userItems = UserItems(crtUser: user!, crtPass: pass!)
            let verification = userItems.loginVerification()
            if verification {
                
                GlobalVariables.LoggedUser = user!
                
                let infoAlert = UIAlertController(title: "Login Successful!", message: "Let's Park Now!", preferredStyle: .alert)
                
                infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in self.displayWelcomeScreen()}))
                
                self.present(infoAlert, animated: true, completion: nil)
                
            }
            else
            {
                let infoAlert = UIAlertController(title: "Unsuccessful!", message: "Username or Password is not correct.", preferredStyle: .alert)
                
                infoAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                
                self.present(infoAlert, animated: true, completion: nil)
            }
        }
}

    
    @IBAction func RegisterButton(_ sender: UIButton) {
        
        //first refer to the file then the screen to go
        let registerSB: UIStoryboard = UIStoryboard(name : "Main", bundle: nil) //main is the file name
        let registerVC = registerSB.instantiateViewController(withIdentifier: "RegisterPage") //registration screen is the identifier for each screen on storyboard
        //self.present(registerVC, animated: true , completion: nil)
        
        navigationController?.pushViewController(registerVC, animated: true)
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        //UserNameText.text = "naveendushila@gmail.com"
        //PasswordText.text = "admin"
        
        if GlobalVariables.LoginRemeber {
            GlobalVariables.LoginRemeber = true
            UserNameText.text = GlobalVariables.LoginUserName
            PasswordText.text = GlobalVariables.LoginPassword
        }
        else
        {
            UserNameText.text = ""
            PasswordText.text = ""
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "PayPark"
        
        let RightButton = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        self.navigationItem.rightBarButtonItem = RightButton
        
        
        
        let LeftButton = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        self.navigationItem.leftBarButtonItem = LeftButton
        
        
        
    }
    

    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func displayWelcomeScreen () {
        let user = GlobalVariables.UserFirstName
        
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "Welcome") as! WelcomeVC
        
        welcomeVC.welcomeTitle = user
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
    }
    
    

}

