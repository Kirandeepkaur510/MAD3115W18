//
//  Email.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit
import MessageUI
class Email: UIViewController , MFMailComposeViewControllerDelegate {

    @IBOutlet weak var UserName: UITextField!
    
    @IBOutlet weak var UserEmail: UITextField!
    
    @IBOutlet weak var UserPhone: UITextField!
    
    @IBOutlet weak var Messgae_Subject: UITextField!
    
    @IBOutlet weak var UserMessage: UITextField!
    
    var userItems: UserItems!
    
    @IBAction func sendMailButton(_ sender: UIButton) {
        
        if UserName.text == "" || UserEmail.text == "" || UserPhone.text == "" || Messgae_Subject.text == "" || UserMessage.text == "" {
            let infoAlert = UIAlertController(title: "Data Missing!", message: "Please enter valid data before submission.", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true, completion: nil)
        }
        else {
            let mailCompose = MFMailComposeViewController()
            mailCompose.mailComposeDelegate = self
            mailCompose.setToRecipients(["CustomerSupport@PayPark.ca"])
            mailCompose.setSubject("\(Messgae_Subject.text!)")
            mailCompose.setMessageBody("\(UserMessage.text!)", isHTML: false)
            if MFMailComposeViewController.canSendMail()
            {
                self.present(mailCompose, animated: true, completion: nil)
                
            }
            else{
                print("E-Mail Sent!!")
            }
        }
      
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userItems = UserItems()
        /*
        UserName.text = "\(userItems.firName[GlobalVariables.LoggedUser]) \(userItems.lasName[GlobalVariables.LoggedUser])"
        UserEmail.text = String(userItems.usrName[GlobalVariables.LoggedUser])
        UserPhone.text = String(userItems.phn[GlobalVariables.LoggedUser])
        */
        
        for i in 0..<GlobalVariables.g_usrName.count {
            if GlobalVariables.g_usrName[i] == GlobalVariables.LoggedUser {
                
                UserName.text = GlobalVariables.g_firName[i]
                UserEmail.text = GlobalVariables.g_usrName[i]
                UserPhone.text = String(describing: GlobalVariables.g_phn[i])
                
            }
            else
            {
                continue
            }
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
