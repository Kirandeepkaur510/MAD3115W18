//
//  UserInfo.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-26.
//  Copyright © 2018 Naveen. All rights reserved.
//

import Foundation
import UIKit

class GlobalVariables: UIViewController {
    
    static var g_usrName = ["test","harinderkaur@gmail.com","kirandeepkaur@gmail.com","naveendushila@gmail.com","nk"]
    static var g_pssWrd = ["test","admin","admin","admin","nk"]
    static var g_firName = ["test","Harinder","KiranDeep","Naveen","Naveen"]
    static var g_lasName = ["test","Kaur","Kaur","Dushila","Dushila"]
    static var g_dtofBirth = [Date(),Date(),Date(),Date(),Date()]
    static var g_phn = [123456789,123456789,123456789,123456789,8645154796]
    static var g_city = ["Test","Brampton","Missisuaga","Toronto","Test"]
    
    
    static var LoggedUser = ""
    static var UserFirstName = ""
    static var LoginRemeber = false
    static var LoginUserName = ""
    static var LoginPassword = ""
    
    static var RunTimeUser = ""
    static var RunTimer = false
    static var RunTImerHrs = 0
    static var RunTimerMins = 0
    static var RunTimerSecs = 0
    
    static var dates: [Int] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]
    static var months: [String] = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"]
    static var years: [Int] = [1975,1976,1977,1978,1979,1980,1981,1982,1983,1984,1985,1986,1987,1988,1989,1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018]
    
    static var vehicleIdentity: [Int] = [1,2,3,4]
    static var vehicleModel: [String] = ["BMW","Honda","Mazda",""]
    static var vehicleRegNumber: [String] = ["ABC123","EFG456","XYZ987",""]
    
    static var paid_VehicleRegNumber: [String] = ["EFG456","XYZ987","ABC123"]
    static var paid_ParkingDate: [Date] = [Date(), Date(),Date()]
    static var paid_ParkingHours: [Int] = [2,3,1]
    static var paid_Amt: [Double] = [11.30,16.95,8.75]
    static var paid_ticketIndex = 0

}
