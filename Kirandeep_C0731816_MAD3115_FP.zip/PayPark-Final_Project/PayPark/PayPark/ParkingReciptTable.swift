//
//  ParkingReciptTable.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class ParkingReciptTable: UIViewController, UITableViewDelegate, UITableViewDataSource {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return GlobalVariables.paid_Amt.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let call = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        call.detailTextLabel?.text = GlobalVariables.paid_VehicleRegNumber[indexPath.row]
        call.textLabel?.text = String(describing: GlobalVariables.paid_ParkingDate[indexPath.row])
        return call
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        GlobalVariables.paid_ticketIndex = indexPath.row
    }

}
