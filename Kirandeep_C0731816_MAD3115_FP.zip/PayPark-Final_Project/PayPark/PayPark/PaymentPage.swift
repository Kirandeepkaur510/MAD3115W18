//
//  PaymentPage.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-24.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class PaymentPage: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {

    var charges = 10
    var parkHours = 1
    var vehicleIndex = 0
    var tax: Double = 0
    var total: Double = 0
    
    @IBOutlet weak var VehNumber: UITextField!
    
    @IBOutlet weak var VehModel: UITextField!
    
    @IBOutlet weak var RegNumber: UITextField!
    
    
    @IBAction func VehicleSelect(_ sender: UITextField) {
        
        VehModel.text = GlobalVariables.vehicleModel[vehicleIndex]
        RegNumber.text = GlobalVariables.vehicleRegNumber[vehicleIndex]
        
    }
    
    @IBOutlet weak var HoursOutlet: UITextField!
    @IBAction func decreaseButton(_ sender: UIButton) {
        
        if parkHours == 1 {
           decreaseButnOutlet.isEnabled = false

        }
        else
        {
            parkHours = parkHours - 1
            if parkHours == 1 {
                decreaseButnOutlet.isEnabled = false
                
            }
            HoursOutlet.text = "\(parkHours) Hr"
           calculate_park_charges()
            
        }
        
    }
    
    @IBOutlet weak var decreaseButnOutlet: UIButton!
    
    @IBAction func increaseButton(_ sender: UIButton) {
            decreaseButnOutlet.isEnabled = true
            parkHours = parkHours + 1
            HoursOutlet.text = "\(parkHours) Hr"
            calculate_park_charges()
    }
    
    
    @objc func calculate_park_charges ()
    {
        charges = parkHours * 5
        
        tax = Double(charges) * 0.13
        
        total = Double(charges) + tax
        
        ParkingCharges.text = String("$\(charges)")
        
        HST.text = String("$\(tax)")
        
        TotalAmt.text = String("$\(total)")
    }
    
  
    @IBOutlet weak var parkLocation: UITextField!
    
    @IBOutlet weak var ParkingCharges: UILabel!
    
    @IBOutlet weak var HST: UILabel!
    
    @IBOutlet weak var TotalAmt: UILabel!
    
    @IBOutlet weak var CardHolderName: UITextField!
    
    @IBOutlet weak var CardNumber: UITextField!
    
    @IBOutlet weak var CVVNo: UITextField!
    
    @IBOutlet weak var ExpiryMM: UITextField!
    
    @IBOutlet weak var ExpiryYYYY: UITextField!
    
    @IBAction func MakePayment(_ sender: UIButton) {
        
        displayPayValues()
        
        GlobalVariables.paid_Amt.append(total)
        GlobalVariables.paid_ParkingDate.append(Date())
        GlobalVariables.paid_ParkingHours.append(parkHours)
        GlobalVariables.paid_VehicleRegNumber.append(RegNumber.text!)
        
        
       
        
    }
    
    
    func displayWelcomeScreen () {
        let user = GlobalVariables.UserFirstName
        
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "Welcome") as! WelcomeVC
        
        welcomeVC.welcomeTitle = user
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //-- Parking Hours and Amounts
        decreaseButnOutlet.isEnabled = false
        HoursOutlet.isEnabled = false
        HoursOutlet.text = "1 Hr"
        ParkingCharges.text = "$5"
        HST.text = "$0.65"
        TotalAmt.text = "$5.65"
        
        //Vehicle Picker View
        
        pickerView.delegate = self
        pickerView.dataSource = self
        VehNumber.inputView = pickerView
        VehNumber.textAlignment = .left
        VehModel.isEnabled = false
        RegNumber.isEnabled = false
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {

        self.navigationItem.title = "Payment"
        
         let btnPayment = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayPayValues))
        
        self.navigationItem.rightBarButtonItem = btnPayment
    }
    

    @objc private func displayPayValues()
    {
       let Vehicle = RegNumber.text
        let Hours  = parkHours
        let paymentchages = TotalAmt.text
        let cardno = CardNumber.text
        let cardname = CardHolderName.text
        let cvv = CVVNo.text
        let mm = ExpiryMM.text
        let yyyy = ExpiryYYYY.text
        
        if paymentchages == "$0.0" {
            let infoAlert = UIAlertController(title: "Payment Charges Are Nil!", message: "Please check the details before payment!", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true)
            
        }
        
        else if cardno == "" || cardname == "" || cvv == "" || mm == "" || yyyy == ""
        {
            let infoAlert = UIAlertController(title: "Card Information Missing!", message: "Please enter all the card details before submission!", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true)
            
        }
        else {
            let allPayData : String = """
            Parking Vehicle: \(Vehicle!)
            Parking Hours: \(parkHours)
            ***Payment Info***
            Card Holder Name: \(cardname!)
            Card Number: \(cardno!)
            """
            
            let infoAlert = UIAlertController(title: "Continue with Payment?", message: allPayData, preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayPayMessage()}))
            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            self.present(infoAlert, animated: true)
            
            GlobalVariables.RunTimer = true
            GlobalVariables.RunTImerHrs = parkHours
            GlobalVariables.RunTimeUser = GlobalVariables.LoggedUser
            
        }
        
 }
    
    func displayPayMessage () {
        let infoAlert = UIAlertController(title: "Ticket Paid!", message: "Enjoy your stay with us.", preferredStyle: .alert)
        
        infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in self.displayWelcomeScreen()}))
        
        self.present(infoAlert, animated: true)
    }
    
    var pickerView = UIPickerView()
    
    func numberOfComponents(in pickerView:UIPickerView) -> Int{
        return 1
    }
    func pickerView(_ pickerView: UIPickerView ,numberOfRowsInComponent component: Int) -> Int {
        return GlobalVariables.vehicleIdentity.count-1
    }
    
    func pickerView(_ pickerView: UIPickerView ,titleForRow row : Int , forComponent component : Int) -> String?{
        vehicleIndex = row
        return String(GlobalVariables.vehicleIdentity[row])
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        VehNumber.text = String(GlobalVariables.vehicleIdentity[row])
        VehNumber.resignFirstResponder()
    }
    
    
   
}
