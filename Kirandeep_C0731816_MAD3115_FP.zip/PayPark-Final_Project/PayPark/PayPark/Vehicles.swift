//
//  Vehicles.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-26.
//  Copyright © 2018 Naveen. All rights reserved.
//

import Foundation
/*
class vehicles: UserItems {
    
    var vehicleNo: [String]
    
    override init()
    {
        super.init()
        self.vehicleNo = ["ABC123","XYZ123"]
    }
    
    
}

 */

