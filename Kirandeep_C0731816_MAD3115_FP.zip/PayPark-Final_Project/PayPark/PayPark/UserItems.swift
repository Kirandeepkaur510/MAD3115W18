//
//  UserItems.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-24.
//  Copyright © 2018 Naveen. All rights reserved.
//

import Foundation


class UserItems {

    var currentUser: String?
    var currentPass: String?
    
    init()
    {
        
        self.currentUser = ""
        self.currentPass = ""
        
    }
    
    init(crtUser: String, crtPass: String)
    {

        self.currentUser = crtUser
        self.currentPass = crtPass
        
        
    }
    
    func loginVerification () -> Bool {
        for i in 0..<GlobalVariables.g_usrName.count {
            if GlobalVariables.g_usrName[i] == self.currentUser! && GlobalVariables.g_pssWrd[i] == self.currentPass!
            {
                GlobalVariables.UserFirstName = GlobalVariables.g_firName[i]
                return true
            }
            else
            {
                continue
            }
         }
        return false
    }
    
}
