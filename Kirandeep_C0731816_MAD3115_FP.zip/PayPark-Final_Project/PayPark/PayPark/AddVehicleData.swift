//
//  AddVehicleData.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

class AddVehicleData: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    var vehicleIndex: Int = 0
    var loadIndex: Int = 0
    
    @IBOutlet weak var VehUNum: UITextField!
    
    @IBOutlet weak var VehModel: UITextField!
    
    @IBOutlet weak var VehRegNumber: UITextField!
    
    @IBAction func VehUnumAction(_ sender: UITextField) {
     VehModel.text = GlobalVariables.vehicleModel[vehicleIndex]
        VehRegNumber.text = GlobalVariables.vehicleRegNumber[vehicleIndex]
    }
    @IBAction func AddVehicle(_ sender: UIButton) {
        if VehModel.text == "" || VehRegNumber.text == "" {
            let infoAlert = UIAlertController(title: "Data Missing!", message: "Please Enter Model and Registration Number.", preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(infoAlert, animated: true, completion: nil)
        }
        else
        {
            let alldata: String = """
            Vehicle Identity Number: \(VehUNum.text!)
            Vehicle Model: \(VehModel.text!)
            Vehicle Registration Number: \(VehRegNumber.text!)
            """
            let infoAlert = UIAlertController(title: "Verify", message: alldata, preferredStyle: .alert)
            
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayWelcomeScreen()}))
            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            self.present(infoAlert, animated: true)
            
            
        }
    }
    
    func displayWelcomeScreen () {
        if vehicleIndex<loadIndex {
            GlobalVariables.vehicleIdentity[vehicleIndex] = Int(VehUNum.text!)!
            GlobalVariables.vehicleModel[vehicleIndex] = VehModel.text!
            GlobalVariables.vehicleRegNumber[vehicleIndex] = VehRegNumber.text!
            
        }
        else {
        GlobalVariables.vehicleIdentity[vehicleIndex] = Int(VehUNum.text!)!
        GlobalVariables.vehicleModel[vehicleIndex] = VehModel.text!
        GlobalVariables.vehicleRegNumber[vehicleIndex] = VehRegNumber.text!
        
        GlobalVariables.vehicleIdentity.append(GlobalVariables.vehicleIdentity.count+1)
        GlobalVariables.vehicleModel.append("")
        GlobalVariables.vehicleRegNumber.append("")
        }
        
        let infoAlert = UIAlertController(title: "Vehicle Added Successfully!", message: "Let's Pay Park Now!", preferredStyle: .alert)
                
        infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in self.LoadHomeScreen()}))
        self.present(infoAlert, animated: true)
        
    }
    
    
    func LoadHomeScreen () {
    
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "Welcome") as! WelcomeVC
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView.delegate = self
        pickerView.dataSource = self
        VehUNum.inputView = pickerView
        VehUNum.textAlignment = .left
        
        loadIndex = GlobalVariables.vehicleIdentity.count-1
        
        VehUNum.text = String(GlobalVariables.vehicleIdentity[loadIndex])
        VehModel.text = GlobalVariables.vehicleModel[loadIndex]
        VehRegNumber.text = GlobalVariables.vehicleRegNumber[loadIndex]
        
 // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var pickerView = UIPickerView()
    
    func numberOfComponents(in pickerView:UIPickerView) -> Int{
        return 1
    }
    func pickerView(_ pickerView: UIPickerView ,numberOfRowsInComponent component: Int) -> Int {
        return GlobalVariables.vehicleIdentity.count
    }
    
    func pickerView(_ pickerView: UIPickerView ,titleForRow row : Int , forComponent component : Int) -> String?{
        vehicleIndex = row
        return String(GlobalVariables.vehicleIdentity[row])
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        VehUNum.text = String(GlobalVariables.vehicleIdentity[row])
        VehUNum.resignFirstResponder()
    }
    

}
