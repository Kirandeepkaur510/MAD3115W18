//
//  UserProfile.swift
//  LaunchScreen_PayPark
//
//  Created by MacStudent on 2018-02-24.
//  Copyright © 2018 Naveen. All rights reserved.
//

import UIKit

var createtemp = 0


class UserProfile: UIViewController {

    var userItems: UserItems!
    var globalUserIndex: Int = 0
    
    @IBOutlet weak var firstname: UITextField!
    @IBOutlet weak var LastName: UITextField!
    @IBOutlet weak var DOB: UITextField!
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Phone: UITextField!
    
    @IBOutlet weak var city: UITextField!
    @IBOutlet weak var psswrd: UITextField!
    @IBOutlet weak var psswrd1: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        userItems = UserItems()
        
       for i in 0..<GlobalVariables.g_usrName.count {
            if GlobalVariables.g_usrName[i] == GlobalVariables.LoggedUser {
                globalUserIndex = i
                firstname.text = GlobalVariables.g_firName[i]
                LastName.text = GlobalVariables.g_lasName[i]
                DOB.text = String(describing: GlobalVariables.g_dtofBirth[i])
                Email.text = GlobalVariables.g_usrName[i]
                Phone.text = String(describing: GlobalVariables.g_phn[i])
                city.text = GlobalVariables.g_city[i]
                psswrd1.text = GlobalVariables.g_pssWrd[i]
                psswrd.text = GlobalVariables.g_pssWrd[i]
                
            }
            else
            {
                continue
            }
        
        }
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "User Profile"
        
        let btnUpdate = UIBarButtonItem(title: "Update", style: .plain, target: self, action: #selector(displayUpdateValues))
        
        self.navigationItem.rightBarButtonItem = btnUpdate
        
    }
    
    @IBAction func userUpdate(_ sender: UIButton) {
        displayUpdateValues()
    }
    
    @objc private func displayUpdateValues() {
        if firstname.text == "" || LastName.text == "" || DOB.text == "" || Email.text == "" || Phone.text == "" || city.text == "" || psswrd.text == "" || psswrd1.text == ""
        {
            let infoAlert = UIAlertController(title: "Data Missing", message: "Please enter all the data before proceeding.", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(infoAlert, animated: true)
        }
        else if psswrd.text != psswrd1.text
        {
            let infoAlert = UIAlertController(title: "Password Error!", message: "Please enter password again.", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(infoAlert, animated: true)
        }
        else {
        let alldata : String = """
        First Name: \(firstname.text!)
        Last Name: \(LastName.text!)
        Date: \(DOB.text!)
        E-Mail: \(Email.text!)
        Phone: \(Phone.text!)
        City: \(city.text!)
        """
        
        let infoAlert = UIAlertController(title: "Update Information", message: alldata, preferredStyle: .alert)
        
        infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displaymessage()}))
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        self.present(infoAlert, animated: true)
        }
        
    }
    
    func displaymessage () {
       
        GlobalVariables.g_firName[globalUserIndex] = firstname.text!
        GlobalVariables.g_lasName[globalUserIndex] = LastName.text!
        //DOB.text = String(describing: GlobalVariables.g_dtofBirth[i])
        GlobalVariables.g_usrName[globalUserIndex] = Email.text!
        GlobalVariables.g_phn[globalUserIndex] = Int(Phone.text!)!
        GlobalVariables.g_city[globalUserIndex] = city.text!
        GlobalVariables.g_pssWrd[globalUserIndex] = psswrd1.text!
        GlobalVariables.g_pssWrd[globalUserIndex] = psswrd.text!
        GlobalVariables.LoggedUser = Email.text!
        
        
        
        let infoAlert = UIAlertController(title: "Profile Updated Successfully!", message: "You can continue with PayPark.", preferredStyle: .alert)
        infoAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in self.displayWelcomeScreen()}))
        self.present(infoAlert, animated: true)
    }

    func displayWelcomeScreen () {
        let user = GlobalVariables.UserFirstName
        
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "Welcome") as! WelcomeVC
        
        welcomeVC.welcomeTitle = user
        
        navigationController?.pushViewController(welcomeVC, animated: true)
        
    }
    
    
    
}
