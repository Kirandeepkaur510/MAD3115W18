//
//  RegisterVC.swift
//  LoginRegister
//
//  Created by Jigisha Patel on 2018-02-21.
//  Copyright © 2018 JK. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource {
    
   // @IBOutlet var txtName: UITextField!
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtPostal: UITextField!
    @IBOutlet weak var txtContact: UITextField!
    @IBOutlet weak var txtDate: UIDatePicker!
   
    @IBOutlet weak var cityPicker: UIPickerView!
    
    
    var cityList: [String] = ["Vancouver","Toronto","Montreal","Surrey","Edmonton","Calgary","Pickering","Quebec","Windsor","Calgary","Dowson Creek","Kamloops","Ajax"]
    
    var selectcityIndex: Int = 0
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Register"
        
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayValues))
        
        self.navigationItem.rightBarButtonItem = btnSubmit
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1 //we have only one column
    }
    //this function returns the number of cities in picker
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.cityList.count
    }
    // this function retrieves the value of select city
    func pickerView(_ pickerView: UIPickerView,titleForRow row: Int,forComponent component : Int) ->String? {
        return self.cityList[row]
    }
    
    
    @objc private func displayValues(){
        self.selectcityIndex = self.cityPicker.selectedRow(inComponent: 0)
        let allData: String = "\(self.txtName.text!) \n \(self.txtEmail.text!) \n \(self.txtPassword.text!) \n \(self.txtPostal.text!) \n \(self.txtDate.date) \n \(self.cityList[selectcityIndex])"
        
        //Action Sheet
      // let infoAlert = UIAlertController(title: "Verify", message: "Please verify your details", preferredStyle: .alert)
        let infoAlert = UIAlertController(title: "Verify your details", message: allData, preferredStyle: .alert)
       
      infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
      infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayWelcomeScreen()}))
      self.present(infoAlert, animated: true)
    }
    
    func displayWelcomeScreen(){
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "WelcomeScreen") as! WelcomeVC
        welcomeVC.welcomeTitle = txtName.text!
        navigationController?.pushViewController(welcomeVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //add data to the picker
        self.cityPicker.delegate = self
        self.cityPicker.dataSource = self
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
