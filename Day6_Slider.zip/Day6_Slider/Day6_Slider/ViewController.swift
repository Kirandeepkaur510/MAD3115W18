//
//  ViewController.swift
//  Day6_Slider
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var segmenter: UISegmentedControl!
    
    @IBOutlet weak var imagemood: UIImageView!
    
    @IBOutlet weak var myStepper: UIStepper!
    
    @IBOutlet weak var lblProgress: UILabel!
    @IBOutlet weak var myProgressiveView: UIProgressView!
    
    @IBOutlet weak var mySlider: UISlider!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
   
    var moodImages: [UIImage] = [
        UIImage(named: "happy.jpeg")!,
        UIImage(named: "sad.jpeg")!,
        UIImage(named: "angry.jpeg")!
    
    ]
    var progressTimer = Timer()
    
    @IBAction func btnStart(_ sender: UIButton) {
       activityIndicator.startAnimating()
        
    }
    @IBAction func btnStop(_ sender: UIButton) {
        activityIndicator.stopAnimating()
        
    }
    
    @IBAction func segmentAction(_ sender: UISegmentedControl) {
        
        print("selected: \(segmenter.selectedSegmentIndex)")
        imagemood.image = moodImages[segmenter.selectedSegmentIndex]
    }
    
    @IBOutlet weak var lblStepper: UILabel!
    @IBAction func myStepperAction(_ sender: UIStepper) {
        lblStepper.text = String(myStepper.value)
    }
    
    @IBOutlet weak var lblSlider: UILabel!
    
    @IBAction func SliderAction(_ sender: UISlider) {
        lblSlider.text = String(mySlider.value)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet weak var image: UIImageView!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

